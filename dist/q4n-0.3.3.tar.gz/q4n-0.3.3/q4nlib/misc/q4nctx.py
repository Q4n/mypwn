libc = None
binary = None
code,heap,stack = None,None,None
