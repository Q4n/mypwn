from __future__ import absolute_import


from q4nlib.misc import log

__all__ = ['log']